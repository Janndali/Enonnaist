package it.slyce.messaging.listeners;

/**
 * Created by matthewpage on 6/28/16.
 */
public interface UserClicksAvatarPictureListener {
    public void userClicksAvatarPhoto(String userId);
}
