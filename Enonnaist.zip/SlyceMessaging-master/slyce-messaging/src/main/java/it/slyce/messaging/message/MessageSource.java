package it.slyce.messaging.message;

/**
 * Created by matthewpage on 6/21/16.
 */
public enum MessageSource {
    LOCAL_USER,
    EXTERNAL_USER,
    GENERAL
}
