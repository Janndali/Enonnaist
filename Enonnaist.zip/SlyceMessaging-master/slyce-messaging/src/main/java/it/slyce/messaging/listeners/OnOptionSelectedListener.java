package it.slyce.messaging.listeners;


public interface OnOptionSelectedListener {
    String onOptionSelected(int optionSelected);
}
